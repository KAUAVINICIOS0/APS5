package chatapp.servidor;

import java.io.*;
import java.net.*;
import java.util.*;

public class Servidor {
    private static final int PORTA = 12345;
    private static List<ClienteHandler> clientes = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) throws IOException {
        ServerSocket servidor = new ServerSocket(PORTA);
        System.out.println("Servidor iniciado na porta " + PORTA);

        while (true) {
            Socket socket = servidor.accept();
            ClienteHandler handler = new ClienteHandler(socket);
            clientes.add(handler);
            new Thread(handler).start();
        }
    }

    static class ClienteHandler implements Runnable {
        private Socket socket;
        private BufferedReader leitor;
        private PrintWriter saida;
        private String nome;

        public ClienteHandler(Socket socket) throws IOException {
            this.socket = socket;
            this.leitor = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.saida = new PrintWriter(socket.getOutputStream(), true);
        }

        public void run() {
            try {
                // Primeira mensagem: nome do usuário
                nome = leitor.readLine();
                broadcast(">> " + nome + " entrou no chat");

                String linha;
                while ((linha = leitor.readLine()) != null) {
                    if (linha.startsWith("[ARQUIVO]")) {
                        // Parse do cabeçalho
                        String[] partes = linha.substring(9).split(":");
                        String[] infoArquivo = partes[0].split("@");
                        String destinatario = infoArquivo[0];
                        String nomeArquivo = infoArquivo[1];
                        long tamanho = Long.parseLong(partes[1]);

                        // Encontrar destinatário
                        ClienteHandler clienteDestino = null;
                        synchronized (clientes) {
                            for (ClienteHandler c : clientes) {
                                if (c.nome.equals(destinatario)) {
                                    clienteDestino = c;
                                    break;
                                }
                            }
                        }

                        if (clienteDestino == null) {
                            saida.println("Usuário '" + destinatario + "' não encontrado.");
                            continue;
                        }

                        // Enviar cabeçalho ao destinatário
                        clienteDestino.saida.println("[ARQUIVO]" + nomeArquivo + ":" + tamanho);

                        // Transferência binária
                        byte[] buffer = new byte[4096];
                        int bytesLidos;
                        long totalLido = 0;
                        InputStream input = socket.getInputStream();
                        OutputStream out = clienteDestino.socket.getOutputStream();

                        while (totalLido < tamanho &&
                               (bytesLidos = input.read(buffer, 0, (int)Math.min(buffer.length, tamanho - totalLido))) != -1) {
                            out.write(buffer, 0, bytesLidos);
                            totalLido += bytesLidos;
                        }
                        out.flush();
                    } else {
                        broadcast("[" + nome + "]: " + linha);
                    }
                }
            } catch (IOException e) {
                System.out.println("Conexão encerrada com " + nome);
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {}
                clientes.remove(this);
                broadcast("<< " + nome + " saiu do chat");
            }
        }

        private void broadcast(String mensagem) {
            synchronized (clientes) {
                for (ClienteHandler cliente : clientes) {
                    cliente.saida.println(mensagem);
                }
            }
        }
    }
}
